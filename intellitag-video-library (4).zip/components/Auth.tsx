import React, { useState } from 'react';
import * as authService from '../services/authService';
import type { User } from '../types';

interface AuthProps {
    onLogin: (user: User) => void;
    onClose: () => void;
}

const FilmReelIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M4 4h16v2H4V4zm0 14h16v2H4v-2zm16-4h-2v-2h2v2zm0-4h-2V8h2v2zM4 16h2v-2H4v2zm0-4h2v-2H4v2zm12-4H8v6h8V8zm-2 4h-4v-2h4v2z" />
    </svg>
);

const XIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);


export const Auth: React.FC<AuthProps> = ({ onLogin, onClose }) => {
    const [isLoginView, setIsLoginView] = useState(true);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState<string | null>(null);
    const [successMessage, setSuccessMessage] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setSuccessMessage(null);

        try {
            if (isLoginView) {
                const user = await authService.login(email, password);
                onLogin(user);
            } else {
                await authService.signup(name, email, password);
                setSuccessMessage("Account created successfully! An administrator will review your request shortly.");
                setIsLoginView(true);
                setName('');
                setEmail('');
                setPassword('');
            }
        } catch (err) {
            if (err instanceof Error) {
                setError(err.message);
            } else {
                setError("An unknown error occurred.");
            }
        }
    };

    return (
        <div className="relative w-full max-w-md bg-gray-800 rounded-lg shadow-xl">
            <div className="flex flex-col items-center pt-8">
                <FilmReelIcon className="w-12 h-12 text-teal-500" />
                <h1 className="text-3xl mt-2 font-bold tracking-tight text-white">IntelliTag</h1>
            </div>

            <div className="p-8">
                <button onClick={onClose} className="absolute top-3 right-3 p-2 rounded-full hover:bg-gray-700 transition-colors" aria-label="Close">
                    <XIcon className="w-5 h-5 text-gray-400" />
                </button>

                <h2 className="text-2xl font-bold text-center text-white mb-6">
                    {isLoginView ? 'Welcome Back' : 'Create Account'}
                </h2>
                {error && <div className="text-red-400 bg-red-900/50 p-3 rounded-md mb-4 text-center">{error}</div>}
                {successMessage && <div className="text-green-300 bg-green-900/50 p-3 rounded-md mb-4 text-center">{successMessage}</div>}

                <form onSubmit={handleSubmit} className="space-y-6">
                    {!isLoginView && (
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-300">Name</label>
                            <input
                                id="name"
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required
                                className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                            />
                        </div>
                    )}
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-300">Email Address</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-300">Password</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-teal-600 hover:bg-teal-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200"
                    >
                        {isLoginView ? 'Login' : 'Sign Up'}
                    </button>
                </form>

                <p className="mt-6 text-center text-sm text-gray-400">
                    {isLoginView ? "Don't have an account?" : "Already have an account?"}
                    <button onClick={() => { setIsLoginView(!isLoginView); setError(null); setSuccessMessage(null); }} className="ml-2 font-semibold text-teal-500 hover:text-teal-400">
                        {isLoginView ? 'Sign up' : 'Login'}
                    </button>
                </p>
            </div>
        </div>
    );
};