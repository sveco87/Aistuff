import React, { useState, useRef, useEffect } from 'react';
import type { VideoData, GlobalPerson } from '../types';
import { getChatRecommendations } from '../services/geminiService';
import { ChatBubble } from './ChatBubble';
import { Loader } from './Loader';
import type { VectorStore } from '../services/vectorService';

interface AIChatProps {
    allVideos: VideoData[];
    people: GlobalPerson[];
    vectorStore: VectorStore;
}

interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}

const SendIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
    </svg>
);

export const AIChat: React.FC<AIChatProps> = ({ allVideos, people, vectorStore }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { role: 'model', text: "Describe the video you're trying to create, and I'll suggest the best clips from your library!" }
    ]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSendMessage = async () => {
        if (!userInput.trim() || isLoading) return;

        const newMessages: ChatMessage[] = [...messages, { role: 'user', text: userInput }];
        setMessages(newMessages);
        const query = userInput;
        setUserInput('');
        setIsLoading(true);
        
        try {
            const responseText = await getChatRecommendations(query, vectorStore, allVideos, people);
            setMessages([...newMessages, { role: 'model', text: responseText }]);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
            setMessages([...newMessages, { role: 'model', text: `Sorry, I ran into an error: ${errorMessage}` }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSendMessage();
        }
    }

    return (
        <div className="bg-gray-800 rounded-lg shadow-xl flex flex-col h-[calc(100vh-10rem)] max-h-[800px]">
            <div className="p-4 border-b border-gray-700">
                <h2 className="text-xl font-bold">AI Video Assistant</h2>
                <p className="text-sm text-gray-400">Find the perfect clip</p>
            </div>
            <div className="flex-grow p-4 overflow-y-auto">
                {messages.map((msg, index) => (
                    <ChatBubble key={index} role={msg.role} text={msg.text} />
                ))}
                {isLoading && (
                    <div className="flex justify-start items-center gap-3 my-4">
                         <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-500/20 flex items-center justify-center text-teal-400">
                           <Loader />
                        </div>
                        <div className="bg-gray-700 rounded-lg px-4 py-2">
                           <span className="italic text-gray-400">Finding clips...</span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-4 border-t border-gray-700">
                <div className="relative">
                    <input
                        type="text"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder="e.g., 'a clip for an opening sequence...'"
                        className="w-full bg-gray-700 border border-gray-600 rounded-full py-2 pl-4 pr-12 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                        disabled={isLoading}
                    />
                    <button 
                        onClick={handleSendMessage}
                        disabled={isLoading || !userInput.trim()}
                        className="absolute right-1 top-1/2 -translate-y-1/2 p-2 rounded-full bg-teal-600 text-white hover:bg-teal-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors"
                        aria-label="Send message"
                    >
                       <SendIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>
        </div>
    );
};