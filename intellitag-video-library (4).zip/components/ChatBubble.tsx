import React from 'react';

interface ChatBubbleProps {
    text: string;
    role: 'user' | 'model';
}

const UserIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

const BotIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3.75H19.5a.75.75 0 01.75.75v11.25a.75.75 0 01-1.5 0V6.31L5.03 20.03a.75.75 0 01-1.06-1.06L17.69 5.25H9a.75.75 0 010-1.5z" />
</svg>
);


export const ChatBubble: React.FC<ChatBubbleProps> = ({ text, role }) => {
    const isUser = role === 'user';

    return (
        <div className={`flex items-start gap-3 my-4 ${isUser ? 'justify-end' : ''}`}>
            {!isUser && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-teal-500/20 flex items-center justify-center text-teal-400">
                    <BotIcon className="w-5 h-5" />
                </div>
            )}
            <div
                className={`max-w-md rounded-lg px-4 py-2 whitespace-pre-wrap ${
                    isUser
                        ? 'bg-teal-600 text-white rounded-br-none'
                        : 'bg-gray-700 text-gray-200 rounded-bl-none'
                }`}
            >
                {text}
            </div>
            {isUser && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-gray-300">
                   <UserIcon className="w-6 h-6 p-0.5" />
                </div>
            )}
        </div>
    );
};