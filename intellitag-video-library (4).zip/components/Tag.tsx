

import React from 'react';

interface TagProps {
    text: string;
    type: 'ai' | 'custom';
    onRemove?: () => void;
}

const XIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);


export const Tag: React.FC<TagProps> = ({ text, type, onRemove }) => {
    const baseClasses = 'flex items-center text-xs font-medium rounded-full px-2.5 py-1';
    const typeClasses = {
        ai: 'bg-teal-500/20 text-teal-300',
        custom: 'bg-indigo-500/20 text-indigo-300',
    };

    return (
        <div className={`${baseClasses} ${typeClasses[type]} group`}>
            <span>{text}</span>
            {onRemove && (
                 <button onClick={onRemove} className="ml-1.5 opacity-50 group-hover:opacity-100 transition-opacity">
                    <XIcon className="w-2.5 h-2.5" />
                </button>
            )}
        </div>
    );
};
