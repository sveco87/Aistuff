// FIX: Replaced placeholder content with a Notification component implementation.
import React, { useEffect } from 'react';

interface NotificationProps {
    message: string;
    type: 'success' | 'error' | 'warning';
    onClose: () => void;
}

const XIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const CheckCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const ExclamationCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const ExclamationTriangleIcon: React.FC<{ className?: string }> = ({ className }) => (
     <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
);


export const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 5000);

        return () => {
            clearTimeout(timer);
        };
    }, [onClose]);

    const typeConfig = {
        success: {
            icon: <CheckCircleIcon className="w-6 h-6" />,
            classes: 'bg-green-600',
        },
        error: {
            icon: <ExclamationCircleIcon className="w-6 h-6" />,
            classes: 'bg-red-600',
        },
        warning: {
            icon: <ExclamationTriangleIcon className="w-6 h-6" />,
            classes: 'bg-yellow-600',
        }
    };
    
    const { icon, classes } = typeConfig[type];
    const baseClasses = 'fixed top-5 right-5 z-50 flex items-center p-4 rounded-lg shadow-lg text-white max-w-sm';

    return (
        <div className={`${baseClasses} ${classes}`}>
            <div className="flex-shrink-0">
                {icon}
            </div>
            <div className="ml-3 text-sm font-medium">{message}</div>
            <button
                onClick={onClose}
                className="ml-auto -mx-1.5 -my-1.5 bg-white/20 hover:bg-white/30 rounded-lg p-1.5 inline-flex h-8 w-8"
                aria-label="Close"
            >
                <XIcon className="w-5 h-5" />
            </button>
        </div>
    );
};