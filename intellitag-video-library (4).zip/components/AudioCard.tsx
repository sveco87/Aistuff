import React, { useState } from 'react';
import type { AudioData } from '../types';
import { Tag } from './Tag';
import { Loader } from './Loader';

interface AudioCardProps {
    audio: AudioData;
    onDelete: (id: string) => void;
    onAddTag: (id: string, tag: string) => void;
    onRemoveTag: (id: string, tag: string, isCustom: boolean) => void;
    isGuestView?: boolean;
}

const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
);

const TrashIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

const MusicIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 6l12-3" />
    </svg>
);


export const AudioCard: React.FC<AudioCardProps> = ({ audio, onDelete, onAddTag, onRemoveTag, isGuestView }) => {
    const [customTagInput, setCustomTagInput] = useState('');

    const handleAddTag = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            onAddTag(audio.id, customTagInput);
            setCustomTagInput('');
        }
    };

    return (
        <div className="bg-gray-800 rounded-lg shadow-xl overflow-hidden flex flex-col transition-transform duration-300 hover:scale-105">
            <div className="relative p-4 bg-gray-900 flex items-center justify-center aspect-video">
                 {audio.isAnalyzing && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/70 z-10">
                        <Loader />
                        <span className="ml-3 text-sm font-medium">Analyzing...</span>
                    </div>
                )}
                 {audio.error && (
                    <div className="absolute inset-0 flex items-center justify-center bg-red-900/80 z-10 p-4 text-center">
                       <p className="text-sm text-red-200">{audio.error}</p>
                    </div>
                )}
                <MusicIcon className="h-24 w-24 text-teal-700" />
            </div>

            <div className="p-4 flex-grow flex flex-col gap-4">
                <div>
                     <h3 className="font-bold text-lg truncate" title={audio.name}>{audio.name}</h3>
                     <p className="text-xs text-gray-400">Uploaded by: {audio.uploadedBy.userName}</p>
                     <audio src={audio.url} controls className="w-full mt-2" />
                </div>
               
                <div className="flex-grow">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase mb-2">Tags</h4>
                    <div className="flex flex-wrap gap-2">
                        {audio.aiTags.map(tag => <Tag key={tag} text={tag} type="ai" onRemove={!isGuestView ? () => onRemoveTag(audio.id, tag, false) : undefined} />)}
                        {audio.customTags.map(tag => <Tag key={tag} text={tag} type="custom" onRemove={!isGuestView ? () => onRemoveTag(audio.id, tag, true) : undefined} />)}
                    </div>
                </div>

                {!isGuestView && (
                    <div>
                        <div className="relative">
                            <input
                                type="text"
                                value={customTagInput}
                                onChange={(e) => setCustomTagInput(e.target.value)}
                                onKeyDown={handleAddTag}
                                placeholder="Add custom tag..."
                                className="w-full bg-gray-700 border border-gray-600 rounded-md py-1.5 pl-8 pr-2 text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                                disabled={audio.isAnalyzing}
                            />
                            <PlusIcon className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                        </div>
                    </div>
                )}
                
                <div className="pt-4 border-t border-gray-700 flex justify-end items-center gap-3">
                    <a href={audio.url} download={audio.name} className="p-2 rounded-full text-gray-400 hover:bg-green-800 hover:text-white transition-colors" title="Download Audio">
                        <DownloadIcon className="w-5 h-5" />
                    </a>
                    {!isGuestView && (
                        <button onClick={() => onDelete(audio.id)} className="p-2 rounded-full text-gray-400 hover:bg-red-800 hover:text-white transition-colors" title="Delete Audio">
                            <TrashIcon className="w-5 h-5" />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};
