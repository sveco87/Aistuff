import React, { useCallback, useState, useRef } from 'react';

interface VideoUploaderProps {
    onFileUpload: (files: FileList) => void;
}

const UploadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M12 15l-3-3m0 0l3-3m-3 3h12" />
    </svg>
);

export const VideoUploader: React.FC<VideoUploaderProps> = ({ onFileUpload }) => {
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleDrag = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setIsDragging(true);
        } else if (e.type === 'dragleave') {
            setIsDragging(false);
        }
    }, []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onFileUpload(e.dataTransfer.files);
        }
    }, [onFileUpload]);
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onFileUpload(e.target.files);
        }
    };

    const handleClick = () => {
        fileInputRef.current?.click();
    };

    const dragClasses = isDragging ? 'border-teal-500 bg-gray-700/50' : 'border-gray-600 bg-gray-800';

    return (
        <div
            className={`relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors duration-200 ease-in-out ${dragClasses}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={handleClick}
        >
            <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept="video/*,audio/*"
                multiple
                onChange={handleChange}
            />
            <div className="flex flex-col items-center justify-center space-y-4 text-gray-400">
                <UploadIcon className="w-12 h-12" />
                <p className="text-lg">
                    <span className="font-semibold text-teal-500">Click to upload</span> or drag and drop videos or music
                </p>
                <p className="text-sm">MP4, MOV, MP3, WAV, etc.</p>
            </div>
        </div>
    );
};
