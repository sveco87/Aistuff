import React from 'react';
import type { User, Profile } from '../types';

const FilmReelIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M4 4h16v2H4V4zm0 14h16v2H4v-2zm16-4h-2v-2h2v2zm0-4h-2V8h2v2zM4 16h2v-2H4v2zm0-4h2v-2H4v2zm12-4H8v6h8V8zm-2 4h-4v-2h4v2z" />
    </svg>
);

const AdminIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

interface HeaderProps {
    user: User | null;
    activeProfile: Profile | null;
    onLogout: () => void;
    onSwitchProfile: () => void;
    onOpenAdminPanel: () => void;
    onLoginClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, activeProfile, onLogout, onSwitchProfile, onOpenAdminPanel, onLoginClick }) => {
    return (
        <header className="bg-gray-800 shadow-lg">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center gap-3">
                        <FilmReelIcon className="w-8 h-8 text-teal-500" />
                        <h1 className="text-2xl font-bold tracking-tight text-white">IntelliTag Video Library</h1>
                    </div>
                    {user ? (
                        <div className="flex items-center gap-4">
                            {activeProfile && (
                                <div className="flex items-center gap-2">
                                     <div className={`w-8 h-8 rounded-full ${activeProfile.avatar} flex items-center justify-center text-sm font-bold text-white/90`}>
                                        {activeProfile.name.charAt(0).toUpperCase()}
                                    </div>
                                    <span className="text-sm text-gray-300">
                                        <span className="font-semibold">{activeProfile.name}</span>
                                    </span>
                                    <button onClick={onSwitchProfile} className="text-xs text-gray-400 hover:text-teal-400">(Switch)</button>
                                </div>
                            )}
                            {user.role === 'admin' && (
                                <button onClick={onOpenAdminPanel} className="p-2 rounded-full text-gray-300 hover:bg-gray-700 hover:text-white transition-colors" title="Admin Panel">
                                    <AdminIcon className="w-5 h-5" />
                                </button>
                            )}
                            <button onClick={onLogout} className="text-sm font-medium text-teal-400 hover:text-teal-300">
                                Logout
                            </button>
                        </div>
                    ) : (
                         <button onClick={onLoginClick} className="text-sm font-medium bg-teal-600 hover:bg-teal-500 text-white px-4 py-2 rounded-md transition-colors">
                            Login / Sign Up
                        </button>
                    )}
                </div>
            </div>
        </header>
    );
};