import React from 'react';
import { VideoCard } from './VideoCard';
import { AudioCard } from './AudioCard';
import type { MediaData, GlobalPerson } from '../types';

interface VideoGridProps {
    media: MediaData[];
    globalPeople: GlobalPerson[];
    onDelete: (id: string) => void;
    onAddTag: (id:string, tag: string) => void;
    onRemoveTag: (id: string, tagToRemove: string, isCustom: boolean) => void;
    onIdentifyPerson: (videoId: string, tempId: string, identity: { newName: string; thumbnail: string } | { existingId: string }) => void;
    isGuestView?: boolean;
}

export const VideoGrid: React.FC<VideoGridProps> = ({ media, globalPeople, onDelete, onAddTag, onRemoveTag, onIdentifyPerson, isGuestView }) => {
    if (media.length === 0) {
       return null;
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            {media.map(item => {
                if (item.type === 'video') {
                    return (
                        <VideoCard 
                            key={item.id} 
                            video={item} 
                            globalPeople={globalPeople}
                            onDelete={onDelete} 
                            onAddTag={onAddTag}
                            onRemoveTag={onRemoveTag}
                            onIdentifyPerson={onIdentifyPerson}
                            isGuestView={isGuestView}
                        />
                    );
                }
                if (item.type === 'audio') {
                    return (
                         <AudioCard
                            key={item.id}
                            audio={item}
                            onDelete={onDelete}
                            onAddTag={onAddTag}
                            onRemoveTag={onRemoveTag}
                            isGuestView={isGuestView}
                        />
                    )
                }
                return null;
            })}
        </div>
    );
};
