import React, { useState, useEffect, useCallback } from 'react';
import * as userService from '../services/userService';
import type { User } from '../types';

interface AdminPanelProps {
    onClose: () => void;
}

const XIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
    const [users, setUsers] = useState<User[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchUsers = useCallback(async () => {
        try {
            setIsLoading(true);
            setError(null);
            const allUsers = await userService.getAllUsers();
            setUsers(allUsers);
        } catch (err) {
            setError("Failed to load users. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    const handleUpdateStatus = async (userId: string, status: User['status']) => {
        try {
            await userService.updateUserStatus(userId, status);
            fetchUsers(); // Refresh the list
        } catch (err) {
            setError("Failed to update user status.");
            console.error(err);
        }
    };
    
    const getStatusColor = (status: User['status']) => {
        switch (status) {
            case 'approved': return 'bg-green-500/20 text-green-300';
            case 'pending': return 'bg-yellow-500/20 text-yellow-300';
            case 'rejected': return 'bg-red-500/20 text-red-300';
            default: return 'bg-gray-500/20 text-gray-300';
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center p-4 border-b border-gray-700">
                    <h2 className="text-xl font-bold">Admin Panel - User Management</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700">
                        <XIcon className="w-5 h-5" />
                    </button>
                </div>
                <div className="p-4 overflow-y-auto">
                    {isLoading && <p>Loading users...</p>}
                    {error && <p className="text-red-400">{error}</p>}
                    {!isLoading && !error && (
                        <div className="divide-y divide-gray-700">
                            {users.map(user => (
                                <div key={user.id} className="flex items-center justify-between py-3">
                                    <div className="flex-1">
                                        <p className="font-semibold">{user.name}</p>
                                        <p className="text-sm text-gray-400">{user.email}</p>
                                    </div>
                                     <div className="flex-1 flex items-center gap-2">
                                        <span className={`text-xs font-medium rounded-full px-2.5 py-1 ${getStatusColor(user.status)}`}>
                                            {user.status}
                                        </span>
                                         {user.role === 'admin' && (
                                            <span className="text-xs font-medium rounded-full px-2.5 py-1 bg-teal-500/20 text-teal-300">
                                                Admin
                                            </span>
                                        )}
                                    </div>
                                    <div className="flex-1 flex justify-end gap-2">
                                        {user.role !== 'admin' && (
                                            <>
                                                <button disabled={user.status === 'approved'} onClick={() => handleUpdateStatus(user.id, 'approved')} className="text-xs font-semibold bg-green-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-3 py-1 rounded-md transition-colors">Approve</button>
                                                <button disabled={user.status === 'rejected'} onClick={() => handleUpdateStatus(user.id, 'rejected')} className="text-xs font-semibold bg-red-600 hover:bg-red-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-3 py-1 rounded-md transition-colors">Reject</button>
                                                <button disabled={user.status === 'pending'} onClick={() => handleUpdateStatus(user.id, 'pending')} className="text-xs font-semibold bg-yellow-600 hover:bg-yellow-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-3 py-1 rounded-md transition-colors">Set Pending</button>
                                            </>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};