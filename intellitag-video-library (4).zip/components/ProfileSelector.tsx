import React, { useState, useEffect, useCallback } from 'react';
import * as profileService from '../services/profileService';
import type { User, Profile } from '../types';
import { Loader } from './Loader';

const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
    </svg>
);

const ProfileCard: React.FC<{ profile: Profile; onSelect: (profile: Profile) => void }> = ({ profile, onSelect }) => (
    <div onClick={() => onSelect(profile)} className="cursor-pointer group flex flex-col items-center gap-4 w-40">
        <div className={`w-40 h-40 rounded-md ${profile.avatar} flex items-center justify-center text-6xl font-bold text-white/80 group-hover:scale-105 group-hover:shadow-lg group-hover:shadow-teal-500/20 transition-transform`}>
            {profile.name.charAt(0).toUpperCase()}
        </div>
        <p className="text-xl text-gray-300 group-hover:text-white transition-colors">{profile.name}</p>
    </div>
);

const AddProfileCard: React.FC<{ onClick: () => void }> = ({ onClick }) => (
    <div onClick={onClick} className="cursor-pointer group flex flex-col items-center gap-4 w-40">
        <div className="w-40 h-40 rounded-md bg-gray-700 flex items-center justify-center text-gray-400 group-hover:bg-gray-600 group-hover:text-white group-hover:scale-105 transition-all">
            <PlusIcon className="w-20 h-20" />
        </div>
        <p className="text-xl text-gray-300 group-hover:text-white transition-colors">Add Profile</p>
    </div>
);

interface ProfileSelectorProps {
    user: User;
    onProfileSelect: (profile: Profile) => void;
    onLogout: () => void;
}

export const ProfileSelector: React.FC<ProfileSelectorProps> = ({ user, onProfileSelect, onLogout }) => {
    const [profiles, setProfiles] = useState<Profile[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isAdding, setIsAdding] = useState(false);
    const [newName, setNewName] = useState('');
    const [error, setError] = useState<string | null>(null);

    const loadProfiles = useCallback(async () => {
        setIsLoading(true);
        try {
            const userProfiles = await profileService.getProfilesForUser(user.id);
            setProfiles(userProfiles);
            if (userProfiles.length === 0) {
                setIsAdding(true); // If no profiles, go straight to add mode
            }
        } catch (e) {
            setError('Could not load profiles.');
        } finally {
            setIsLoading(false);
        }
    }, [user.id]);

    useEffect(() => {
        loadProfiles();
    }, [loadProfiles]);

    const handleAddProfile = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newName.trim()) return;
        setError(null);
        try {
            await profileService.createProfile(user.id, newName.trim());
            setNewName('');
            setIsAdding(false);
            loadProfiles();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to create profile.');
        }
    };
    
    const cancelAdd = () => {
        if (profiles.length > 0) {
             setIsAdding(false);
             setError(null);
             setNewName('');
        }
    }

    if (isLoading) {
        return (
            <div className="w-full h-full flex flex-col items-center justify-center text-white">
                <Loader />
                <p className="mt-4">Loading profiles...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-8">
            <div className="text-center">
                <h1 className="text-5xl font-bold mb-4">{isAdding ? 'Create a Profile' : "Who's watching?"}</h1>
                {isAdding && (
                     <p className="text-gray-400 mb-12">Create a profile for a new user on this account.</p>
                )}
            </div>

            {isAdding ? (
                <div className="w-full max-w-sm">
                    <form onSubmit={handleAddProfile} className="flex flex-col gap-4">
                        <input
                            type="text"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            placeholder="Profile Name"
                            className="w-full bg-gray-700 border border-gray-600 rounded-md py-3 px-4 text-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
                            autoFocus
                        />
                         {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                        <div className="flex gap-4 mt-4">
                           <button type="submit" className="flex-1 bg-teal-600 hover:bg-teal-500 text-white font-bold py-3 px-6 rounded-md transition-colors">
                                Create
                           </button>
                           {profiles.length > 0 && (
                                <button type="button" onClick={cancelAdd} className="flex-1 bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-md transition-colors">
                                    Cancel
                                </button>
                           )}
                        </div>
                    </form>
                </div>
            ) : (
                <div className="flex flex-wrap items-start justify-center gap-8 mt-12">
                    {profiles.map(profile => (
                        <ProfileCard key={profile.id} profile={profile} onSelect={onProfileSelect} />
                    ))}
                    {profiles.length < 5 && (
                        <AddProfileCard onClick={() => setIsAdding(true)} />
                    )}
                </div>
            )}
             <button onClick={onLogout} className="mt-20 text-gray-400 hover:text-white border border-gray-600 hover:border-white px-6 py-2 rounded-md transition-colors">
                Log Out
            </button>
        </div>
    );
};
