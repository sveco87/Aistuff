// FIX: Replaced placeholder content with type definitions.
export interface User {
    id: string;
    name: string;
    email: string;
    password?: string; // Should not be sent to client, but needed for mock DB
    role: 'admin' | 'user';
    status: 'approved' | 'pending' | 'rejected';
}

export interface Profile {
    id: string;
    userId: string;
    name: string;
    avatar: string; // e.g., 'bg-red-500'
}

export interface GlobalPerson {
    id: string;
    name: string;
    thumbnail: string; // base64 data URL
}

export interface IdentifiedPerson {
    tempId: string;
    thumbnail: string; // base64 data URL
    globalPersonId: string | null;
}

export interface Scene {
    start: number;
    end: number;
    description: string;
    tags: string[];
    thumbnailIndex: number;
}

interface MediaBase {
    id: string; // Combination of fingerprint and user ID
    name: string;
    url: string; // Object URL
    uploadedBy: {
        userId: string;
        userName?: string; // Legacy support
        profileId?: string;
        profileName?: string;
    };
    aiTags: string[];
    customTags: string[];
    isAnalyzing: boolean;
    error: string | null;
}

export interface VideoData extends MediaBase {
    type: 'video';
    thumbnail: string; // base64 data URL of the first frame
    frames: string[]; // base64 data URLs for hover preview
    duration: number;
    dimensions: {
        width: number;
        height: number;
    };
    description: string;
    people: IdentifiedPerson[];
    transcript: string | null;
    scenes: Scene[];
}

export interface AudioData extends MediaBase {
    type: 'audio';
}

export type MediaData = VideoData | AudioData;

export interface VectorEmbedding {
    id: string; // Corresponds to MediaData id
    vector: number[];
}