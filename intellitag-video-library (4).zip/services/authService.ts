import * as api from './api';
import type { User } from '../types';

const AUTH_TOKEN_KEY = 'intelliTagAuthToken';
const SESSION_PROFILE_KEY = 'intelliTagActiveProfile';

export const signup = async (name: string, email: string, password: string): Promise<User> => {
    return api.signup(name, email, password);
};

export const login = async (email: string, password: string): Promise<User> => {
    const { token, user } = await api.login(email, password);
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    return user;
};

export const logout = (): void => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    sessionStorage.removeItem(SESSION_PROFILE_KEY);
};

export const getAuthenticatedUser = async (): Promise<User | null> => {
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    if (!token) {
        return null;
    }
    try {
        // In a real app, you'd verify the token with the backend.
        // Our mock API simulates this.
        const user = await api.getMe(token);
        return user;
    } catch (error) {
        console.error("Session token is invalid, logging out.", error);
        logout();
        return null;
    }
};