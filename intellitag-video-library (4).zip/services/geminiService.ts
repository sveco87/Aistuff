import { GoogleGenAI, Type } from "@google/genai";
import type { GenerateContentResponse, Part } from "@google/genai";
import type { VideoData, GlobalPerson, Scene } from "../types";
import type { VectorStore } from "./vectorService";
import { generateEmbedding } from './vectorService';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const transcribeAudio = async (file: File): Promise<string> => {
    console.log(`Simulating transcription for ${file.name}...`);
    // In a real app, this would involve extracting audio and calling a speech-to-text API.
    // For this demo, we return a mock transcript based on a common business school topic.
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate network latency
    return "This is a simulated transcript. The main speaker, Dr. Evelyn Reed, discusses disruptive innovation and its impact on traditional marketing funnels. She presents a case study on a tech startup that successfully entered a saturated market. The talk is followed by a brief Q&A session where attendees ask about ROI metrics and long-term brand strategy. The overall tone is academic and informative.";
}

const videoAnalysisPrompt = (duration: number, transcript: string | null) => `
You are an expert video analysis AI for a video editor specializing in content for a business school. Your task is to analyze a series of frames and an optional audio transcript to provide a comprehensive, multi-modal analysis.

The video's duration is ${duration.toFixed(1)} seconds.
${transcript ? `An audio transcript is provided for deeper context:\n---\n${transcript}\n---\n` : ''}

Based on all available information (frames and transcript), perform the following tasks:
1.  **Generate a concise, one-paragraph overall description** of the video's content, action, topics discussed, and overall mood. Synthesize information from both visuals and audio.
2.  **Generate a comprehensive list of descriptive tags.** Use the transcript to add specific topic-related tags. Categories: Core Subject (e.g., "Marketing Strategy", "Finance"), People (e.g., "Students", "Lecturer"), Setting (e.g., "Classroom", "Auditorium"), Actions (e.g., "Presenting", "Collaborating"), Shot Type, and Video Length.
3.  **Identify unique people.** Analyze faces. For each unique person, assign a temporary unique identifier (e.g., 'person_1') and specify the index of the frame (from 0 to N-1) that provides the clearest, most representative portrait of their face.
4.  **Perform Scene Detection.** Group the frames into distinct scenes. A scene is a continuous action in one location. For each scene, provide:
    *   A brief description of what happens in that scene.
    *   Start and end times in seconds. Infer this from the frame indices and total duration.
    *   A list of tags specific to that scene.
    *   The index of the frame that best represents the scene.

Return your response as a single JSON object following the provided schema. Do not include markdown formatting.
`;

const videoResponseSchema = {
  type: Type.OBJECT,
  properties: {
    description: {
      type: Type.STRING,
      description: "A one-paragraph summary of the video content, synthesizing visuals and audio.",
    },
    tags: {
      type: Type.ARRAY,
      description: "A comprehensive list of descriptive tags for the video.",
      items: { type: Type.STRING },
    },
    people: {
      type: Type.ARRAY,
      description: "A list of unique people identified in the video.",
      items: {
        type: Type.OBJECT,
        properties: {
          id: {
            type: Type.STRING,
            description: "A unique identifier for the person, e.g., 'person_1'.",
          },
          bestFrameIndex: {
            type: Type.INTEGER,
            description: "The index of the frame that is the clearest portrait of this person.",
          }
        },
        required: ["id", "bestFrameIndex"],
      },
    },
    scenes: {
        type: Type.ARRAY,
        description: "A list of distinct scenes detected in the video.",
        items: {
            type: Type.OBJECT,
            properties: {
                start: { type: Type.NUMBER, description: "The start time of the scene in seconds." },
                end: { type: Type.NUMBER, description: "The end time of the scene in seconds." },
                description: { type: Type.STRING, description: "A brief description of the scene." },
                tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Tags specific to this scene." },
                thumbnailIndex: { type: Type.INTEGER, description: "The index of the frame that best represents the scene." }
            },
            required: ["start", "end", "description", "tags", "thumbnailIndex"],
        }
    }
  },
  required: ["description", "tags", "people", "scenes"],
};


export const analyzeVideoFrames = async (
    base64Frames: string[],
    duration: number,
    transcript: string | null
): Promise<{ tags: string[]; description: string; people: {id: string; bestFrameIndex: number}[]; scenes: Scene[] }> => {
  try {
    const imageParts: Part[] = base64Frames.map(frame => ({
      inlineData: {
        data: frame.split(',')[1],
        mimeType: 'image/jpeg'
      }
    }));

    const textPart: Part = { text: videoAnalysisPrompt(duration, transcript) };

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [textPart, ...imageParts] },
      config: {
        responseMimeType: "application/json",
        responseSchema: videoResponseSchema,
      }
    });

    const parsed = JSON.parse(response.text.trim());
    return {
        tags: parsed.tags || [],
        description: parsed.description || 'No description generated.',
        people: parsed.people || [],
        scenes: parsed.scenes || [],
    };
  } catch (error) {
    console.error("Error calling Gemini API for video analysis:", error);
    throw new Error("Failed to analyze video. Please check the console for details.");
  }
};


export const getChatRecommendations = async (
    userQuery: string,
    vectorStore: VectorStore,
    allVideos: VideoData[],
    people: GlobalPerson[]
): Promise<string> => {
    try {
        if (allVideos.length === 0) {
            return "Your video library is empty. Please upload some videos first so I can help you find the right clips.";
        }
        
        // RAG Step 1: Retrieve
        // Create an embedding for the user's query, specifying the correct task type.
        const queryEmbedding = await generateEmbedding(userQuery, 'RETRIEVAL_QUERY');

        // RAG Step 2: Search
        // Find the top K most relevant videos from the vector store.
        const searchResults = await vectorStore.search(queryEmbedding, 5);
        
        if (searchResults.length === 0) {
            return "I couldn't find any clips that seem to match your request. Could you try describing it a different way?";
        }

        // RAG Step 3: Augment
        // Get the full data for the relevant videos.
        const relevantVideoIds = new Set(searchResults.map(r => r.id));
        const relevantVideos = allVideos.filter(v => relevantVideoIds.has(v.id));
        const peopleMap = new Map(people.map(p => [p.id, p.name]));

        // Build a focused context string with ONLY the relevant videos.
        const videoLibrarySummary = relevantVideos.map(v => {
            const tags = [...v.aiTags, ...v.customTags].join(', ');
            const peopleNames = v.people
                .map(p => p.globalPersonId ? peopleMap.get(p.globalPersonId) : null)
                .filter(Boolean)
                .join(', ');

            const scenesSummary = v.scenes.map(s => `  - Scene (${s.start.toFixed(1)}s - ${s.end.toFixed(1)}s): ${s.description} [Tags: ${s.tags.join(', ')}]`).join('\n');

            return `- **File:** ${v.name}\n` +
                   `  - **Overall Description:** ${v.description}\n` +
                   `  - **Overall Tags:** [${tags}]\n` +
                   `  - **People:** [${peopleNames || 'None'}]\n` +
                   `${v.transcript ? `  - **Transcript Summary:** ${v.transcript.substring(0, 200)}...\n` : ''}` +
                   `${scenesSummary ? `  - **Scenes:**\n${scenesSummary}` : ''}`;
        }).join('\n\n');

        const chatPrompt = `
You are an intelligent video editing assistant. Your user needs help finding the best clips from their library for a project. You have access to a rich, multi-modal analysis of each video, including a description, tags, people, a scene-by-scene breakdown, and sometimes an audio transcript.

A pre-search has already been performed to find the most relevant clips. Your task is to analyze ONLY these clips and provide a final recommendation.

**User's Request:** "${userQuery}"

**Top Matching Videos from Library:**
${videoLibrarySummary}

Based on the user's request, analyze the provided clips and their detailed data. Your primary goal is to provide highly specific and actionable recommendations.
- Recommend 1-3 of the best videos from the provided list.
- For each recommendation, provide the full video filename.
- **Crucially, if a specific scene or moment is relevant, mention it by its timecode (e.g., "The scene from 15.2s to 25.0s is a great fit because...").**
- Justify each recommendation with a brief, one-sentence explanation, referencing the description, tags, scenes, or transcript.

Format your response clearly. Do not use markdown. If none of the provided videos are a good match, state that and explain why.`;

        // RAG Step 4: Generate
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: chatPrompt,
        });

        return response.text.trim();
    } catch (error) {
        console.error("Error calling Gemini API for chat:", error);
        throw new Error("The AI assistant is currently unavailable. Please try again later.");
    }
};