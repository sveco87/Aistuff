export const createFileFingerprint = async (file: File): Promise<string> => {
    // A simple fingerprint based on file metadata.
    // For more robustness, one could read a few bytes from the file.
    return `${file.name}-${file.size}-${file.lastModified}`;
};
