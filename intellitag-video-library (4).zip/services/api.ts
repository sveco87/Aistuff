import * as db from './dbService';
import type { User } from '../types';

// In a real app, this would be handled by a secure backend.
// For this demo, we'll simulate it.

const MOCK_TOKEN_SECRET = 'supersecretstring';

// Mock "hashing". DO NOT use this in production.
const pseudoHash = (password: string) => `hashed_${password}`;

export const initializeAdmin = async (): Promise<void> => {
    const users = await db.getAllUsers();
    if (users.length === 0) {
        console.log("No users found, creating default admin account.");
        const adminUser: User = {
            id: `user_admin_${Date.now()}`,
            name: 'Admin',
            email: 'adamsvec123@gmail.com',
            password: pseudoHash('Katuska1977?'),
            role: 'admin',
            status: 'approved',
        };
        await db.addUser(adminUser);
    }
};

export const signup = async (name: string, email: string, password: string): Promise<User> => {
    const existingUser = await db.getUserByEmail(email);
    if (existingUser) {
        throw new Error("An account with this email already exists.");
    }

    const newUser: User = {
        id: `user_${Date.now()}`,
        name,
        email,
        password: pseudoHash(password),
        role: 'user', // All new users are standard users
        status: 'pending', // All new users need admin approval
    };

    await db.addUser(newUser);
    return newUser;
};

export const login = async (email: string, password: string): Promise<{ token: string, user: User }> => {
    const user = await db.getUserByEmail(email);
    if (!user || user.password !== pseudoHash(password)) {
        throw new Error("Invalid email or password.");
    }
    if (user.status !== 'approved') {
        if (user.status === 'pending') {
            throw new Error("Your account is pending approval by an administrator.");
        }
        if (user.status === 'rejected') {
            throw new Error("Your account request has been rejected.");
        }
        throw new Error("Your account is not active.");
    }

    // Create a mock token
    const token = `${user.id}::${Date.now()}::${MOCK_TOKEN_SECRET}`;

    return { token, user };
};


export const getMe = async (token: string): Promise<User | null> => {
    try {
        const [userId, timestamp, secret] = token.split('::');
        if (secret !== MOCK_TOKEN_SECRET) {
            return null;
        }
        // In a real app, you'd check the timestamp for expiry
        const user = await db.getUserById(userId);
        return user || null;
    } catch (error) {
        return null;
    }
};

export const getAllUsers = (): Promise<User[]> => {
    return db.getAllUsers();
};

export const updateUserStatus = async (userId: string, status: User['status']): Promise<User> => {
    const user = await db.getUserById(userId);
    if (!user) {
        throw new Error("User not found.");
    }
    const updatedUser = { ...user, status };
    await db.updateUser(updatedUser);
    return updatedUser;
};