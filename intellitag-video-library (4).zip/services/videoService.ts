
export const extractFrames = (
  file: File,
  frameCount: number
): Promise<{ frames: string[]; duration: number; dimensions: { width: number; height: number } }> => {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.playsInline = true;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    if (!context) {
      return reject(new Error('Failed to get 2D context from canvas.'));
    }

    const objectUrl = URL.createObjectURL(file);
    video.src = objectUrl;

    let frames: string[] = [];

    video.onloadedmetadata = () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const duration = video.duration;
      const dimensions = { width: video.videoWidth, height: video.videoHeight };

      if (duration === 0) {
        URL.revokeObjectURL(objectUrl);
        return reject(new Error('Video has no duration.'));
      }
      
      const interval = duration / (frameCount > 1 ? frameCount - 1 : 1);
      let capturedFrames = 0;
      let currentTime = 0;

      const captureFrame = () => {
        video.currentTime = currentTime;
      };

      video.onseeked = () => {
        context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        frames.push(canvas.toDataURL('image/jpeg', 0.8));
        capturedFrames++;

        if (capturedFrames < frameCount) {
          currentTime += interval;
           if (currentTime > duration) currentTime = duration;
          captureFrame();
        } else {
          URL.revokeObjectURL(objectUrl);
          resolve({ frames, duration, dimensions });
        }
      };

      captureFrame();
    };

    video.onerror = (e) => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to load video file. It may be corrupt or in an unsupported format.'));
    };
  });
};
