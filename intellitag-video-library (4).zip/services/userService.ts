import * as api from './api';
import type { User } from '../types';

export const getAllUsers = (): Promise<User[]> => {
    return api.getAllUsers();
};

export const updateUserStatus = (userId: string, status: User['status']): Promise<User> => {
    return api.updateUserStatus(userId, status);
};