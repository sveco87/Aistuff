import type { MediaData, GlobalPerson, User, VectorEmbedding, Profile } from '../types';

const DB_NAME = 'IntelliTagDB';
const DB_VERSION = 5; // Incremented version for schema change
const MEDIA_STORE_NAME = 'media';
const GLOBAL_PEOPLE_STORE_NAME = 'globalPeople';
const USERS_STORE_NAME = 'users';
const VECTOR_STORE_NAME = 'vectors';
const PROFILES_STORE_NAME = 'profiles';

let db: IDBDatabase;

export const initDB = (): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('Error opening database');
      reject('Error opening database');
    };

    request.onsuccess = () => {
      db = request.result;
      resolve(true);
    };

    request.onupgradeneeded = (event) => {
      const dbInstance = (event.target as IDBOpenDBRequest).result;
      if (!dbInstance.objectStoreNames.contains(MEDIA_STORE_NAME)) {
        dbInstance.createObjectStore(MEDIA_STORE_NAME, { keyPath: 'id' });
      }
      if (!dbInstance.objectStoreNames.contains(GLOBAL_PEOPLE_STORE_NAME)) {
        dbInstance.createObjectStore(GLOBAL_PEOPLE_STORE_NAME, { keyPath: 'id' });
      }
      if (!dbInstance.objectStoreNames.contains(USERS_STORE_NAME)) {
        const usersStore = dbInstance.createObjectStore(USERS_STORE_NAME, { keyPath: 'id' });
        usersStore.createIndex('email', 'email', { unique: true });
      }
       if (!dbInstance.objectStoreNames.contains(VECTOR_STORE_NAME)) {
        dbInstance.createObjectStore(VECTOR_STORE_NAME, { keyPath: 'id' });
      }
       if (!dbInstance.objectStoreNames.contains(PROFILES_STORE_NAME)) {
        const profileStore = dbInstance.createObjectStore(PROFILES_STORE_NAME, { keyPath: 'id' });
        profileStore.createIndex('userId', 'userId', { unique: false });
      }
    };
  });
};

// Media Functions
export const addMedia = (mediaData: MediaData): Promise<void> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([MEDIA_STORE_NAME], 'readwrite');
        const store = transaction.objectStore(MEDIA_STORE_NAME);
        const request = store.add(mediaData);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

export const updateMedia = (mediaData: MediaData): Promise<void> => {
     return new Promise((resolve, reject) => {
        const transaction = db.transaction([MEDIA_STORE_NAME], 'readwrite');
        const store = transaction.objectStore(MEDIA_STORE_NAME);
        const request = store.put(mediaData);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

export const getAllMedia = (): Promise<MediaData[]> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([MEDIA_STORE_NAME], 'readonly');
        const store = transaction.objectStore(MEDIA_STORE_NAME);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result as MediaData[]);
        request.onerror = () => reject(request.error);
    });
};

export const deleteMedia = (id: string): Promise<void> => {
     return new Promise((resolve, reject) => {
        const transaction = db.transaction([MEDIA_STORE_NAME], 'readwrite');
        const store = transaction.objectStore(MEDIA_STORE_NAME);
        const request = store.delete(id);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

// Global People Functions
export const addGlobalPerson = (person: GlobalPerson): Promise<void> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([GLOBAL_PEOPLE_STORE_NAME], 'readwrite');
        const store = transaction.objectStore(GLOBAL_PEOPLE_STORE_NAME);
        const request = store.add(person);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
};

export const getAllGlobalPeople = (): Promise<GlobalPerson[]> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([GLOBAL_PEOPLE_STORE_NAME], 'readonly');
        const store = transaction.objectStore(GLOBAL_PEOPLE_STORE_NAME);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result as GlobalPerson[]);
        request.onerror = () => reject(request.error);
    });
};

// User Functions
export const addUser = (user: User): Promise<void> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([USERS_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(USERS_STORE_NAME);
    const request = store.add(user);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const getUserByEmail = (email: string): Promise<User | undefined> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([USERS_STORE_NAME], 'readonly');
    const store = transaction.objectStore(USERS_STORE_NAME);
    const index = store.index('email');
    const request = index.get(email);
    request.onsuccess = () => resolve(request.result as User | undefined);
    request.onerror = () => reject(request.error);
  });
};

export const getUserById = (id: string): Promise<User | undefined> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([USERS_STORE_NAME], 'readonly');
        const store = transaction.objectStore(USERS_STORE_NAME);
        const request = store.get(id);
        request.onsuccess = () => resolve(request.result as User | undefined);
        request.onerror = () => reject(request.error);
    });
};

export const updateUser = (user: User): Promise<void> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([USERS_STORE_NAME], 'readwrite');
        const store = transaction.objectStore(USERS_STORE_NAME);
        const request = store.put(user);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
    });
}

export const getAllUsers = (): Promise<User[]> => {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([USERS_STORE_NAME], 'readonly');
        const store = transaction.objectStore(USERS_STORE_NAME);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result as User[]);
        request.onerror = () => reject(request.error);
    });
};

// Profile Functions
export const addProfile = (profile: Profile): Promise<void> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PROFILES_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(PROFILES_STORE_NAME);
    const request = store.add(profile);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const getProfilesForUser = (userId: string): Promise<Profile[]> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([PROFILES_STORE_NAME], 'readonly');
    const store = transaction.objectStore(PROFILES_STORE_NAME);
    const index = store.index('userId');
    const request = index.getAll(userId);
    request.onsuccess = () => resolve(request.result as Profile[]);
    request.onerror = () => reject(request.error);
  });
};


// Vector Store Functions
export const upsertVector = (embedding: VectorEmbedding): Promise<void> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([VECTOR_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(VECTOR_STORE_NAME);
    const request = store.put(embedding);
    request.onsuccess = () => resolve();
    request.onerror = (e) => {
        console.error("Failed to upsert vector:", request.error);
        reject(request.error);
    }
  });
};

export const getAllVectors = (): Promise<VectorEmbedding[]> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([VECTOR_STORE_NAME], 'readonly');
    const store = transaction.objectStore(VECTOR_STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result as VectorEmbedding[]);
    request.onerror = () => reject(request.error);
  });
};

export const deleteVectorDB = (id: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([VECTOR_STORE_NAME], 'readwrite');
    const store = transaction.objectStore(VECTOR_STORE_NAME);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};