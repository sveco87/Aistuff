import { GoogleGenAI } from "@google/genai";
import type { VideoData, VectorEmbedding } from '../types';
import * as dbService from './dbService';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates a vector embedding for a given text using a Gemini embedding model.
 * @param text The text to embed.
 * @param taskType The intended use of the embedding.
 * @returns A promise that resolves to an array of numbers representing the vector.
 */
export const generateEmbedding = async (
    text: string,
    taskType: 'RETRIEVAL_QUERY' | 'RETRIEVAL_DOCUMENT'
): Promise<number[]> => {
    try {
        const model = 'text-embedding-004';
        
        const response = await ai.models.embedContent({
            model: model,
            contents: text,
            config: {
                taskType: taskType,
            }
        });

        // The response structure returns embeddings array
        const embedding = response.embeddings?.[0]?.values;
        if (!embedding) {
            throw new Error("Embedding not found in the API response.");
        }
        return embedding;
    } catch (error) {
        console.error("Error generating embedding:", error);
        throw new Error("Failed to generate text embedding.");
    }
};

const cosineSimilarity = (vecA: number[], vecB: number[]): number => {
    let dotProduct = 0;
    let magA = 0;
    let magB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        magA += vecA[i] * vecA[i];
        magB += vecB[i] * vecB[i];
    }
    magA = Math.sqrt(magA);
    magB = Math.sqrt(magB);
    if (magA === 0 || magB === 0) {
        return 0;
    }
    return dotProduct / (magA * magB);
};


/**
 * A class for managing an in-memory vector store for fast semantic search,
 * with persistence to IndexedDB.
 */
export class VectorStore {
    private embeddings: Map<string, number[]>;

    constructor() {
        this.embeddings = new Map();
    }

    /**
     * Initializes the store by loading all vectors from IndexedDB into memory.
     */
    async init() {
        const storedVectors = await dbService.getAllVectors();
        this.embeddings = new Map(storedVectors.map(v => [v.id, v.vector]));
        console.log(`VectorStore initialized with ${this.embeddings.size} embeddings.`);
    }

    /**
     * Clears all embeddings from the in-memory store.
     */
    clear() {
        this.embeddings.clear();
        console.log("VectorStore cleared.");
    }
    
    /**
     * Creates a text document from video metadata for embedding.
     */
    private createDocument(video: VideoData): string {
         const peopleNames = video.people
            .map(p => p.globalPersonId ? `Person: ${p.globalPersonId}` : '')
            .filter(Boolean)
            .join(', ');

        const sceneDescriptions = video.scenes
            .map(s => `Scene from ${s.start}s to ${s.end}s: ${s.description} with tags ${s.tags.join(', ')}`)
            .join('. ');

        return `
            Video Title: ${video.name}.
            Description: ${video.description}.
            Tags: ${[...video.aiTags, ...video.customTags].join(', ')}.
            People: ${peopleNames || 'None'}.
            Scenes: ${sceneDescriptions || 'No scenes'}.
            Transcript: ${video.transcript || 'No transcript'}.
        `.replace(/\s+/g, ' ').trim();
    }


    /**
     * Adds a video's generated embedding to the store.
     * @param video The video data to process and add.
     */
    async addVideo(video: VideoData) {
        const document = this.createDocument(video);
        // Use 'RETRIEVAL_DOCUMENT' for storing video metadata
        const vector = await generateEmbedding(document, 'RETRIEVAL_DOCUMENT');
        this.embeddings.set(video.id, vector);
        await dbService.upsertVector({ id: video.id, vector });
    }
    
    /**
     * Builds the search index for all provided videos, generating embeddings
     * only for those that don't already have one.
     */
    async buildIndex(videos: VideoData[]) {
        const indexPromises = videos.map(video => {
            if (!this.embeddings.has(video.id) && !video.isAnalyzing) {
                console.log(`Generating embedding for ${video.name}...`);
                return this.addVideo(video);
            }
            return Promise.resolve();
        });
        await Promise.allSettled(indexPromises);
        console.log("VectorStore index build complete.");
    }

    /**
     * Deletes a vector from the store and the database.
     * @param id The ID of the vector to delete.
     */
    async deleteVector(id: string) {
        this.embeddings.delete(id);
        await dbService.deleteVectorDB(id);
    }

    /**
     * Searches the store for the most similar vectors to a query vector.
     * @param queryVector The vector to search for.
     * @param topK The number of results to return.
     * @returns A sorted array of the top K most similar items.
     */
    async search(queryVector: number[], topK: number): Promise<{ id: string, score: number }[]> {
        const results: { id: string, score: number }[] = [];
        
        for (const [id, vector] of this.embeddings.entries()) {
            const score = cosineSimilarity(queryVector, vector);
            results.push({ id, score });
        }

        results.sort((a, b) => b.score - a.score);

        return results.slice(0, topK);
    }
}