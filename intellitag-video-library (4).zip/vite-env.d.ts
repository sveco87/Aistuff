// FIX: Replaced the failing `vite/client` type reference with manual definitions for `import.meta.env` as a workaround. This resolves errors related to Vite environment variables not being recognized by TypeScript.

interface ImportMetaEnv {
  readonly VITE_API_KEY: string;
  // Add other environment variables here as needed.
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
