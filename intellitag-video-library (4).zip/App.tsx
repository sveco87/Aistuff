// FIX: Replaced placeholder content with a full App component implementation.
import React, { useState, useEffect, useCallback, useMemo } from 'react';

// Components
import { Header } from './components/Header';
import { VideoUploader } from './components/VideoUploader';
import { SearchBar } from './components/SearchBar';
import { VideoGrid } from './components/VideoGrid';
import { AIChat } from './components/AIChat';
import { Loader } from './components/Loader';
import { Auth } from './components/Auth';
import { AdminPanel } from './components/AdminPanel';
import { Notification } from './components/Notification';
import { ProfileSelector } from './components/ProfileSelector';


// Services
import * as dbService from './services/dbService';
import * as authService from './services/authService';
import * as api from './services/api';
import { extractFrames } from './services/videoService';
import { analyzeVideoFrames, transcribeAudio } from './services/geminiService';
import { createFileFingerprint } from './services/mediaService';
import { VectorStore } from './services/vectorService';

// Types
import type { User, MediaData, VideoData, Profile, GlobalPerson } from './types';

const SESSION_PROFILE_KEY = 'intelliTagActiveProfile';

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [activeProfile, setActiveProfile] = useState<Profile | null>(null);
    const [media, setMedia] = useState<MediaData[]>([]);
    const [guestUploads, setGuestUploads] = useState<MediaData[]>([]);
    const [globalPeople, setGlobalPeople] = useState<GlobalPerson[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'warning' } | null>(null);
    const [showAuthModal, setShowAuthModal] = useState(false);
    const [showAdminPanel, setShowAdminPanel] = useState(false);

    const vectorStore = useMemo(() => new VectorStore(), []);
    
    const loadMediaData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [mediaData, peopleData] = await Promise.all([
                dbService.getAllMedia(),
                dbService.getAllGlobalPeople(),
            ]);
            setMedia(mediaData);
            setGlobalPeople(peopleData);
            await vectorStore.init();
            const videos = mediaData.filter(m => m.type === 'video') as VideoData[];
            await vectorStore.buildIndex(videos);
        } catch (error) {
             console.error("Failed to load media data:", error);
            setNotification({ message: "Failed to load library data.", type: 'error' });
        } finally {
            setIsLoading(false);
        }
    }, [vectorStore]);

    const loadInitialState = useCallback(async () => {
        setIsLoading(true);
        try {
            await dbService.initDB();
            await api.initializeAdmin();
            const currentUser = await authService.getAuthenticatedUser();
            setUser(currentUser);

            if (currentUser) {
                const savedProfileJson = sessionStorage.getItem(SESSION_PROFILE_KEY);
                if (savedProfileJson) {
                    const savedProfile: Profile = JSON.parse(savedProfileJson);
                    if (savedProfile.userId === currentUser.id) {
                        setActiveProfile(savedProfile);
                    }
                }
            }
        } catch (error) {
            console.error("Failed to initialize the app:", error);
            setNotification({ message: "App failed to initialize.", type: 'error' });
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadInitialState();
    }, [loadInitialState]);
    
    useEffect(() => {
        if (user && activeProfile) {
            loadMediaData();
        } else if (!user) {
            setMedia([]);
            setGlobalPeople([]);
            vectorStore.clear();
        }
    }, [user, activeProfile, loadMediaData, vectorStore]);


    const handleLogin = (loggedInUser: User) => {
        setUser(loggedInUser);
        setActiveProfile(null); // Force profile selection
        setGuestUploads([]); 
        setShowAuthModal(false);
        setNotification({ message: `Welcome, ${loggedInUser.name}!`, type: 'success' });
    };

    const handleLogout = () => {
        authService.logout();
        setUser(null);
        setActiveProfile(null);
        setNotification({ message: "You have been logged out.", type: 'success' });
    };
    
    const handleProfileSelect = (profile: Profile) => {
        setActiveProfile(profile);
        sessionStorage.setItem(SESSION_PROFILE_KEY, JSON.stringify(profile));
    };

    const handleSwitchProfile = () => {
        setActiveProfile(null);
        sessionStorage.removeItem(SESSION_PROFILE_KEY);
    };

    const updateMediaItem = useCallback(async (updatedItem: MediaData) => {
        if (user) {
            setMedia(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
        } else {
            setGuestUploads(prev => prev.map(item => item.id === updatedItem.id ? updatedItem : item));
        }
        await dbService.updateMedia(updatedItem);
    }, [user]);

    const processVideoFile = useCallback(async (file: File, fingerprint: string) => {
        if (!user || !activeProfile) {
            setNotification({ message: "You must be logged in with a profile to upload.", type: 'error' });
            return;
        }

        const videoId = `${activeProfile.id}-${fingerprint}`;
        
        let currentVideoData: VideoData = {
            id: videoId,
            type: 'video',
            name: file.name,
            url: URL.createObjectURL(file),
            thumbnail: '',
            frames: [],
            isAnalyzing: true,
            error: null,
            duration: 0,
            dimensions: { width: 0, height: 0 },
            description: 'Analyzing...',
            aiTags: [],
            customTags: [],
            people: [],
            transcript: null,
            scenes: [],
            uploadedBy: { 
                userId: user.id, 
                profileId: activeProfile.id,
                profileName: activeProfile.name 
            },
        };

        setMedia(prev => [currentVideoData, ...prev]);
        await dbService.addMedia(currentVideoData);

        try {
            // Step 1: Extract frames
            const { frames, duration, dimensions } = await extractFrames(file, 20);
            const firstFrame = frames[0];
            currentVideoData = { ...currentVideoData, thumbnail: firstFrame, duration, dimensions, frames };
            await updateMediaItem(currentVideoData);
            
            // Step 2: Transcribe audio
            const transcript = await transcribeAudio(file);
            currentVideoData = { ...currentVideoData, transcript };
            await updateMediaItem(currentVideoData);

            // Step 3: Analyze with Gemini
            const analysis = await analyzeVideoFrames(frames, duration, transcript);
            const identifiedPeople = analysis.people.map(p => ({
                tempId: `${videoId}-${p.id}`,
                thumbnail: frames[p.bestFrameIndex],
                globalPersonId: null,
            }));
            
            currentVideoData = {
                ...currentVideoData,
                isAnalyzing: false,
                description: analysis.description,
                aiTags: analysis.tags,
                people: identifiedPeople,
                scenes: analysis.scenes,
            };
            await updateMediaItem(currentVideoData);

            // Step 4: Generate and store embedding for RAG
            await vectorStore.addVideo(currentVideoData);

        } catch (error) {
            console.error(`Failed to process ${file.name}:`, error);
            const errorMessage = error instanceof Error ? error.message : "An unknown error occurred during analysis.";
            await updateMediaItem({ ...currentVideoData, isAnalyzing: false, error: errorMessage });
            throw error; 
        }
    }, [user, activeProfile, updateMediaItem, vectorStore]);

    const handleFileUpload = async (files: FileList) => {
        const existingMedia = await dbService.getAllMedia();
        const uploadPromises: Promise<void | undefined>[] = [];

        for (const file of Array.from(files)) {
            const fingerprint = await createFileFingerprint(file);
            
            if (existingMedia.some(m => m.id.endsWith(fingerprint))) {
                 setNotification({ message: `"${file.name}" is already in the library.`, type: 'warning' });
                continue;
            }

            if (file.type.startsWith('video/')) {
                uploadPromises.push(processVideoFile(file, fingerprint));
            } else {
                 setNotification({ message: `"${file.name}" is not a supported video file.`, type: 'warning' });
            }
        }
        await Promise.allSettled(uploadPromises);
    };
    
    const handleDelete = async (id: string) => {
        const itemToDelete = media.find(m => m.id === id);
        if (!itemToDelete) return;
        
        URL.revokeObjectURL(itemToDelete.url);
        
        setMedia(prev => prev.filter(m => m.id !== id));
        await dbService.deleteMedia(id);
        if (itemToDelete.type === 'video') {
            await vectorStore.deleteVector(id);
        }
        setNotification({ message: `"${itemToDelete.name}" deleted.`, type: 'success' });
    };

    const handleAddTag = async (id: string, tag: string) => {
        const item = media.find(m => m.id === id);
        if (item && tag.trim() && !item.customTags.includes(tag.trim())) {
            const updatedItem = { ...item, customTags: [...item.customTags, tag.trim()] };
            await updateMediaItem(updatedItem);
             if (updatedItem.type === 'video') {
                await vectorStore.addVideo(updatedItem);
            }
        }
    };

    const handleRemoveTag = async (id: string, tag: string, isCustom: boolean) => {
        const item = media.find(m => m.id === id);
        if (item) {
            const updatedItem = {
                ...item,
                customTags: isCustom ? item.customTags.filter(t => t !== tag) : item.customTags,
                aiTags: !isCustom ? item.aiTags.filter(t => t !== tag) : item.aiTags,
            };
            await updateMediaItem(updatedItem);
            if (updatedItem.type === 'video') {
                await vectorStore.addVideo(updatedItem);
            }
        }
    };
    
    const handleIdentifyPerson = async (videoId: string, tempId: string, identity: { newName: string; thumbnail: string } | { existingId: string }) => {
        let globalPersonId: string;
        
        if ('newName' in identity) {
            const newPerson: GlobalPerson = {
                id: `person_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
                name: identity.newName,
                thumbnail: identity.thumbnail,
            };
            setGlobalPeople(prev => [...prev, newPerson]);
            await dbService.addGlobalPerson(newPerson);
            globalPersonId = newPerson.id;
        } else {
            globalPersonId = identity.existingId;
        }

        const video = media.find(m => m.id === videoId) as VideoData;
        if (video) {
            const updatedPeople = video.people.map(p => p.tempId === tempId ? { ...p, globalPersonId } : p);
            const updatedVideo = { ...video, people: updatedPeople };
            updateMediaItem(updatedVideo);
            await vectorStore.addVideo(updatedVideo);
        }
    };

    const filteredMedia = useMemo(() => {
        if (!searchQuery.trim() || !user) {
            return media;
        }
        const lowerCaseQuery = searchQuery.toLowerCase();
        const peopleMap = new Map(globalPeople.map(p => [p.id, p.name.toLowerCase()]));

        return media.filter(item => {
            if (item.name.toLowerCase().includes(lowerCaseQuery)) return true;
            if (item.customTags.some(tag => tag.toLowerCase().includes(lowerCaseQuery))) return true;
            if (item.aiTags.some(tag => tag.toLowerCase().includes(lowerCaseQuery))) return true;
            if (item.type === 'video') {
                if (item.description.toLowerCase().includes(lowerCaseQuery)) return true;
                if (item.transcript?.toLowerCase().includes(lowerCaseQuery)) return true;
                if (item.scenes.some(scene => scene.description.toLowerCase().includes(lowerCaseQuery))) return true;
                if (item.people.some(p => {
                    const personName = p.globalPersonId ? peopleMap.get(p.globalPersonId) : undefined;
                    return typeof personName === 'string' && personName.includes(lowerCaseQuery);
                })) return true;
            }
            return false;
        });
    }, [media, searchQuery, globalPeople, user]);

    if (isLoading && !user) { // Only show full-screen loader on initial app load
        return (
            <div className="bg-gray-900 text-white min-h-screen flex items-center justify-center">
                <Loader />
                <span className="ml-4 text-lg">Loading App...</span>
            </div>
        );
    }
    
    const renderContent = () => {
        if (user && !activeProfile) {
            return <ProfileSelector user={user} onProfileSelect={handleProfileSelect} onLogout={handleLogout} />;
        }

        return (
             <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-8">
                        <div className="space-y-4">
                            <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} disabled={!user} />
                            <VideoUploader onFileUpload={handleFileUpload} />
                        </div>

                         {isLoading && (
                            <div className="text-center py-16">
                                <Loader />
                                <p className="mt-2 text-gray-400">Loading library...</p>
                            </div>
                        )}

                        {!isLoading && user && activeProfile && (
                            <>
                                {filteredMedia.length > 0 ? (
                                    <VideoGrid
                                        media={filteredMedia}
                                        globalPeople={globalPeople}
                                        onDelete={handleDelete}
                                        onAddTag={handleAddTag}
                                        onRemoveTag={handleRemoveTag}
                                        onIdentifyPerson={handleIdentifyPerson}
                                    />
                                ) : (
                                    <div className="text-center py-16 bg-gray-800 rounded-lg">
                                        <h3 className="text-xl font-semibold">Your library is empty.</h3>
                                        <p className="text-gray-400 mt-2">Upload a video to get started!</p>
                                    </div>
                                )}
                            </>
                        )}
                        
                        {!user && (
                            <div className="text-center py-16 bg-gray-800 rounded-lg">
                                <h3 className="text-2xl font-bold text-teal-500">Welcome to IntelliTag</h3>
                                <p className="text-gray-400 mt-2 mb-6">
                                    Log in to access your intelligent media library.
                                </p>
                                <button onClick={() => setShowAuthModal(true)} className="bg-teal-600 hover:bg-teal-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">
                                    Login / Sign Up
                                </button>
                            </div>
                        )}
                    </div>
                    <aside className="lg:col-span-1">
                        {user && activeProfile ? (
                            <AIChat 
                                allVideos={media.filter(m => m.type === 'video') as VideoData[]} 
                                people={globalPeople} 
                                vectorStore={vectorStore}
                            />
                        ): (
                             <div className="bg-gray-800 rounded-lg shadow-xl flex flex-col h-[calc(100vh-10rem)] max-h-[800px] items-center justify-center text-center p-8">
                                <h3 className="text-xl font-bold">AI Assistant</h3>
                                <p className="text-gray-400 mt-2">{!user ? "Log in to chat with the AI." : "Select a profile to begin."}</p>
                            </div>
                        )}
                    </aside>
                </div>
            </main>
        );
    }

    return (
        <div className="bg-gray-900 text-white min-h-screen font-sans">
            <Header
                user={user}
                activeProfile={activeProfile}
                onLogout={handleLogout}
                onSwitchProfile={handleSwitchProfile}
                onOpenAdminPanel={() => setShowAdminPanel(true)}
                onLoginClick={() => setShowAuthModal(true)}
            />
            {renderContent()}
            {showAuthModal && (
                <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
                    <Auth onLogin={handleLogin} onClose={() => setShowAuthModal(false)} />
                </div>
            )}
            {showAdminPanel && user?.role === 'admin' && (
                <AdminPanel onClose={() => setShowAdminPanel(false)} />
            )}
            {notification && (
                <Notification
                    message={notification.message}
                    type={notification.type}
                    onClose={() => setNotification(null)}
                />
            )}
        </div>
    );
};

export default App;